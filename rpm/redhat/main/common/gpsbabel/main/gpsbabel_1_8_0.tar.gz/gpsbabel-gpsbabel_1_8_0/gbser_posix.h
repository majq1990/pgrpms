#ifndef gbser_posix_h
#define gbser_posix_h

#include <termios.h>

speed_t mkspeed(unsigned br);

#endif
