#include <stdarg.h>
int main() { return 0; }
