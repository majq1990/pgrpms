-- CopyRight(c) pgRouting developers
-- Creative Commons Attribution-Share Alike 3.0 License : https://creativecommons.org/licenses/by-sa/3.0/

--------------------------------------------------------------------------------
--                pgr_version
--------------------------------------------------------------------------------
/* -- q1 */
SELECT version, library FROM pgr_full_version();
/* -- q2 */
