..
   ****************************************************************************
    pgRouting Manual
    Copyright(c) pgRouting Contributors

    This documentation is licensed under a Creative Commons Attribution-Share
    Alike 3.0 License: https://creativecommons.org/licenses/by-sa/3.0/
   ****************************************************************************

|


Reference
===============================================================================

.. index from here

* :doc:`pgr_version`
* :doc:`pgr_full_version`

.. index to here

.. toctree::
    :hidden:

    pgr_version
    pgr_full_version

See Also
-------------------------------------------------------------------------------

.. rubric:: Indices and tables

* :ref:`genindex`
* :ref:`search`
